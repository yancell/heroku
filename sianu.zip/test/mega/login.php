<?php

	require_once("config.php");
	
    echo "http://".$d."/auth/login_defor.php?userid=".$c."&sessid=".uniqid() . time()."&access_token=4d296641ff48a7d3f790a33d9f0ac923&sess&sesskey=".uniqid() . time()."&is_kyc=false";