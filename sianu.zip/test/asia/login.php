<?php

	require_once("config.php");
	
    echo "http://".$d."/auth/login_defor.php?userid=".$c."&sessid=".uniqid() . time()."&access_token=ae73bd59bc11845040421281c0a6e10d&sesskey=".uniqid() . time()."&is_kyc=false";