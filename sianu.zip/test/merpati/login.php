<?php

	require_once("config.php");
	
    echo "http://".$d."/auth/login_defor.php?userid=".$c."&sessid=".uniqid() . time()."&access_token=2ab3f256f585b44356dbebed390f5dc2&sesskey=".uniqid() . time()."&is_kyc=false";