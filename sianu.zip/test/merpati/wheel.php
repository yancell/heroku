<?php

    if (!$target){
        echo "ERROR";
        exit;
    }
    
	$value = cut($cnt, 'klanklcnaklasdac:', ', anim');
	$parcel = cut($cnt, "bbc7=", ";");
	$accept1 = cut($cnt, "date_prz = [", ',"NULL"');
	$accept2 = cut($cnt, "hasil_prz = [", ',"NULL"');
	$total = cut($cnt, 'numb_kupn = ', ';');
	$session = cut($cnt, "gassxx= '", "'");
	$arr = @json_decode($value);
	
	if (is_array($arr)){
	    $finish = null;
		foreach ($arr as $k => $v){
			if (!empty($v)){
			    $finish = false;
			    if (in_array($var[$k], $target)){
			        file_put_contents("cookie".$user."data.txt", serialize(["target" => $var[$k], "session" => $session]));
			        $finish = true;
			    }
				echo json_encode([
				    "result" => $var[$k],
				    "bonus" => $total,
				    "session" => $session,
				    "total" => $v,
				    "finish" => $finish,
				    "parcel" => json_decode($parcel),
				    "key" => $k,
				    "accept" => json_decode("[".$accept1.",".$accept2."]")
				]);
				exit;
			}
		}
		if ($finish == null){
			echo json_encode([
			    "result" => 0,
			    "bonus" => $total,
			    "session" => $session,
			    "total" => null,
			    "finish" => $finish,
			    "parcel" => json_decode($parcel),
			    "key" => 0,
			    "accept" => json_decode("[".$accept1.",".$accept2."]")
			]);
		    exit;
		}
	}
	
	echo "ERROR";