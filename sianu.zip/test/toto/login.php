<?php

	require_once("config.php");
	
    echo "http://".$d."/auth/login_defor.php?userid=".$c."&sessid=".uniqid() . time()."&access_token=8cfaef457939f90b4fac0819c1b21208";