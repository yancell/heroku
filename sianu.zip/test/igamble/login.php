<?php

	require_once("config.php");
	
    echo "http://".$d."/auth/login_defor.php?userid=".$c."&sessid=".uniqid() . time()."&access_token=817d4f76ace98d65dec984091b2a4ba2&sesskey=".uniqid() . time()."&is_kyc=false";