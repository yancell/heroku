<?php

	require_once("config.php");
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://".$c."/refresh-csrf");
	curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie".$user.".txt");
	curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie".$user.".txt");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$cnt = curl_exec($ch);
	curl_close($ch);
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://".$c."/authentication/login");
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'X-CSRF-TOKEN: '.$cnt,
        'X-Requested-With: XMLHttpRequest'
    ]);
	curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie".$user.".txt");
	curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie".$user.".txt");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, "username=".$user."&password=".$password);
    curl_exec($ch);
	curl_close($ch);

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_NOBODY, 1);
	curl_setopt($ch, CURLOPT_URL, "https://".$c."/fortune/under-prefix");
	curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie".$user.".txt");
	curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie".$user.".txt");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_exec($ch);
	$info = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
	curl_close($ch);
	$parse = parse_url($info);	parse_str($parse["query"], $query);
    $info = str_replace($parse["host"], $d, $info);
    
    if ($c == $parse["host"]){
        unlink("cookie".$user.".txt");
        echo "ERROR";
        exit;
    }
    
    echo $info;
